package com.example.myapplication.ui;
import static java.util.concurrent.TimeUnit.MILLISECONDS;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
public class MyTimer134 {public interface CallBack {
    void execute();
}
    public interface LeftCallBack {
        void execute(long left);
    }
    CallBack finalCallback;
    LeftCallBack tickCallback;
    ScheduledExecutorService scheduler;
    long st;
    public MyTimer134(CallBack finalCallback, LeftCallBack tickCallback) {
        this.finalCallback = finalCallback;
        this.tickCallback = tickCallback;
        st = 0;
    }
    public void start(long ticks) {
        st = ticks;
        scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(this::tick, 0, 100, MILLISECONDS);
    }
    void tick() {
        st--;
        tickCallback.execute(st);
        if (st <= 0) {
            scheduler.shutdown();
            scheduler = null;
            finalCallback.execute();
        }
    }
}