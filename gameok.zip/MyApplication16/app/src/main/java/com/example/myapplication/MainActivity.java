package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.ui.MyTimer134;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    Object[] items;
    static long GO = 50;
    Button Right;
    Button Left;
    TextView message;
    TextView countDown;
    ImageView stone;
    MyTimer134 before, gogogo;
    String task;
    String Choice;
    int dodje = 0;
    private int dodges;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Right = (Button) findViewById(R.id.Right);
        Bundle r = new Bundle();
        Right.setOnClickListener(v -> {
            Choice = "right";
        });
        Left = (Button) findViewById(R.id.Left);
        Left.setOnClickListener(v -> {
            Choice = "left";
        });
        message = (TextView) findViewById(R.id.message);
        countDown = (TextView) findViewById(R.id.countDown);
        stone = (ImageView) findViewById(R.id.stone);
        before = new MyTimer134(
                () -> {
                    runOnUiThread(this::generateTask);
                },
                left -> {
                });
        gogogo = new MyTimer134(
                () -> {
                    runOnUiThread(this::timeout);
                },
                left -> runOnUiThread(() -> updateTask(left))
        );
        presetup();
    }

    @Override
    protected void onResume() {
        super.onResume();
        presetup();
        dodje=0;
    }

    void presetup() {
        stone.setVisibility(View.INVISIBLE);
        message.setText("Пока ничего");
        countDown.setText("");
        before.start(80);
    }

    void updateTask(long left) {
        message.setText(task);
        countDown.setText("" + left / 10.0f);

        double half = Math.PI / 4;
        double angle = Math.atan2(1, 1 + 20 * ((float) left) / GO);

//        double scale = 1 - ((float) left) / GO;
        double scale = 1.5 * angle / half;

        stone.setScaleX((float) scale);
        stone.setScaleY((float) scale);
    }

    void generateTask() {
        stone.setVisibility(View.VISIBLE);
        stone.setScaleX(0.1f);
        stone.setScaleY(0.1f);
        Choice = "";
        Random r = new Random();
        if (r.nextBoolean()) {
            task = "left";
        } else {
            task = "right";
        }
        gogogo.start(GO);
    }

    void timeout() {
        stone.setVisibility(View.INVISIBLE);
        int duration = Toast.LENGTH_SHORT;
        if (task.equals(Choice)) {
            Toast toast = Toast.makeText(this, "Молодец!", duration);
            toast.show();
            dodje = dodje + 1;
            presetup();
        } else {
            Bundle r = new Bundle();
            Intent i = new Intent(this, GameOverActivity.class);
            r.putInt("key1",dodje);
            i.putExtras(r);
            startActivity(i);
            //Toast toast = Toast.makeText(this, "О нет! Вы уклонились " + dodje + " раз. Ты можешь лучше", duration);
            //toast.show();
            //Intent over = new Intent(MainActivity.this, GameOverActivity.class);
        }
    }
}