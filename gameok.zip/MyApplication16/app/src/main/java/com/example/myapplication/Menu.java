package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Menu extends AppCompatActivity {
    Button play;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_menu);
        play = (Button) findViewById(R.id.play);
        play.setOnClickListener(v -> {
            Intent over = new Intent(Menu.this, MainActivity.class);
            startActivity(over);
            finish();
        });
    }
}