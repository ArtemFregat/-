package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
public class GameOverActivity extends AppCompatActivity {
    Button Retry;
    Button gomenu;
    TextView dodgesum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_game_over);
        super.onCreate(savedInstanceState);
        Bundle i = getIntent().getExtras();
        int col = i.getInt("key1");
        dodgesum = (TextView) findViewById(R.id.dodgesum);
        dodgesum.setText("Вы уклонились "+ col +" раз. Вы можете лучше");

        Retry = (Button) findViewById(R.id.gogame);
        Retry.setOnClickListener(v -> {
            finish();
        });
        gomenu = (Button) findViewById(R.id.gomenu);
        gomenu.setOnClickListener(v -> {
            Intent over = new Intent(GameOverActivity.this, Menu.class);
            startActivity(over);
            finish();
        });
    }
}